
<?php

	require_once 'dbconfig.php';
	
	if(isset($_GET['delete_id']))
	{
		// select image from db to delete
		$stmt_select = $DB_con->prepare('SELECT userPic FROM tbl_users WHERE userID =:uid');
		$stmt_select->execute(array(':uid'=>$_GET['delete_id']));
		$imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
		unlink("user_images/".$imgRow['userPic']);
		
		// it will delete an actual record from db
		$stmt_delete = $DB_con->prepare('DELETE FROM tbl_users WHERE userID =:uid');
		$stmt_delete->bindParam(':uid',$_GET['delete_id']);
		$stmt_delete->execute();
		
		header("Location: index.php");
	}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap/js/bootstrap.min.js"></script>
    

    
    
    
    
    
    
    
<style>
    
    @import url(https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css);
@import url(https://fonts.googleapis.com/css?family=Raleway:500,700);
.fill {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.snip1337 {
  font-family: 'Raleway', Arial, sans-serif;
  position: relative;
  float: left;
  overflow: hidden;
  margin-bottom: 30%;
  min-width: 99%;
  max-width: 99%;
  max-height:370px;
    min-height: 240px;
 
  background: #2980b9;
  text-align: left;
  color: #ffffff;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.15);
  font-size: 16px;
}
.snip1337 * {
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.snip1337 > img,
.snip1337 .image img {
  -webkit-transform: scale(1.05);
  transform: scale(1.05);
  max-width: 100%;
}
.snip1337 > img {
  vertical-align: top;
  position: relative;
  -webkit-filter: blur(5px);
  filter: blur(5px);
  opacity: 0.7;
}
.snip1337 .image {
  position: absolute;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  overflow: hidden;
  -webkit-transition-delay: 0.2s;
  transition-delay: 0.2s;
}
.snip1337 .image img {
  position: absolute;
  bottom: 0;
}
.snip1337 figcaption {
  opacity: 0;
  position: absolute;
  top: 20px;
  left: 20px;
  right: 20px;
  border-bottom: 2px solid #ffffff;
  padding-bottom: 15px;
  z-index: 1;
    color: black;
}
.snip1337 h3,
.snip1337 p {
  margin: 0;
}
.snip1337 h3 {
  font-weight: 700;
  margin-bottom: 5px;
  text-transform: uppercase;
}
.snip1337 p {
  font-size: 0.9em;
  letter-spacing: 1px;
  font-weight: 400;
}
.snip1337 .read-more {
  display: block;
  opacity: 0;
  -webkit-transform: translateX(-20px);
  transform: translateX(-20px);
  line-height: 48px;
  text-transform: uppercase;
  letter-spacing: 1px;
  padding: 0 20px;
  color: #ffffff;
  right: 0;
  bottom: 0;
  font-weight: 500;
  position: absolute;
  -webkit-transition-delay: 0s;
  transition-delay: 0s;
}
.snip1337 a {
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  position: absolute;
  z-index: 1;
}
.snip1337:hover .read-more,
.snip1337.hover .read-more,
.snip1337:hover figcaption,
.snip1337.hover figcaption {
  opacity: 1;
  -webkit-transform: translateX(0px);
  transform: translateX(0px);
  -webkit-transition-delay: 0.2s;
  transition-delay: 0.2s;
}
.snip1337:hover .image,
.snip1337.hover .image {
  top: 100%;
  -webkit-transition-delay: 0s;
  transition-delay: 0s;
}
/* Demo purposes only */
    
    
    /*body {
  background-color: #212121;
}*/
    
    </style>    
    
    
    
    
    
</head>
<body style="background-image: url(bg.jpg);">

	<?php include 'navhome.php'; ?>
	<div id="wrapper"  >

	<div class="container" >
    
    	<div class="page-header">
    	<h3>Library Management System</h3>
    	</div>
        
        <div class="row">
        <div class="col-lg-12">
        <h1>Books</h1>
        </div>
        </div>
    
    </div>
    
    </div>
    <div class="container" style="background-color: white">

	
    
<br />

<div class="row">
<?php
	
	$stmt = $DB_con->prepare('SELECT userID, title, auther,pub,edition,isbn,price,copy, userPic FROM tbl_users ORDER BY userID DESC');
	$stmt->execute();
	
	if($stmt->rowCount() > 0)
	{
		while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		{
			extract($row);
			?>
			<div class="col-xs-3">
				<p class="h4" ><?php echo $title."&nbsp;/&nbsp;".$auther; ?></p>
                    <hr>
				
                
				<figure class="snip1337">
               <img src="user_images/<?php echo $row['userPic']; ?>" height="370px"   />
                <div class="image"><img src="user_images/<?php echo $row['userPic']; ?>" height="370px" /></div>
                <figcaption>
                <h3><?php echo $title?></h3>
                <p>Writer: <?php echo $auther?>
                    Price: $<?php echo $price?>
                  
                
                </p>
                    
                    <hr>
                    Writer: <?php echo $auther?><br>
                    Price: $<?php echo $price?>
                </figcaption><span class="read-more">
                    <hr>
     
                Read More <i class="ion-android-arrow-forward"></i></span>
                <a href="#"></a>
                </figure>
                 
			</div> 
    
			<?php
		}
	}
	else
	{
		?>
        <div class="col-xs-12">
        	<div class="alert alert-warning">
            	<span class="glyphicon glyphicon-info-sign"></span> &nbsp; No Data Found ...
            </div>
        </div>
        <?php
	}
	
?>
</div>	



<div class="alert alert-info">
    <strong>tutorial link !</strong> <a href="http://www.codingcage.com/2016/02/upload-insert-update-delete-image-using.html">Coding Cage</a>!
</div>

</div>




    
    
    
</body>
</html>
<?php ob_end_flush(); ?>