<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">

            <li><a href="homeuser.php">HOME</a></li>
            <li><a href="books.php">Books</a></li>
          
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
          <li><a href="index.php">Admin Login</a></li>
             
           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 