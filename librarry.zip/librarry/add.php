
<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['Submit'])) {	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	$dob = mysqli_real_escape_string($mysqli, $_POST['dob']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$city = mysqli_real_escape_string($mysqli, $_POST['city']);
	$province = mysqli_real_escape_string($mysqli, $_POST['province']);
	$post = mysqli_real_escape_string($mysqli, $_POST['post']);
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);
	$link = mysqli_real_escape_string($mysqli, $_POST['link']);
	$djoin = mysqli_real_escape_string($mysqli, $_POST['djoin']);
	$pay = mysqli_real_escape_string($mysqli, $_POST['pay']);

		
	// checking empty fields
	if(empty($name) || empty($gender) || empty($dob) || empty($address) || empty($city) || empty($province) ||empty($post) || empty($email) || empty($link) || empty($djoin) || empty($pay)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($gender)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($dob)) {
			echo "<font color='red'>DoB field is empty.</font><br/>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($city)) {
			echo "<font color='red'>City field is empty.</font><br/>";
		}

		if(empty($province)) {
			echo "<font color='red'>Province field is empty.</font><br/>";
		}

		if(empty($post)) {
			echo "<font color='red'>Post field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($link)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($djoin)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($pay)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO users(name,gender,dob,address,city,province,post,email,link,djoin,pay) VALUES('$name','$gender','$dob','$address','$city',
			'$province','$post','$email','$link','$djoin','$pay')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>




<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>




<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body class="fixed-bg" style="background-image: url(i.jpg);">

	<?php include 'nav.php'; ?>


	<div id="wrapper" style="background-image: url(i.jpg);">

  <div class="container" >
    
      <div class="page-header">
      <h3>Payroll Management System</h3>
      </div>
        
        
<div class="container" style="background-color: skyblue">
<div class="container" style="width: 40%">
  <h2>Employees Registration</h2>



 <form action="add.php" method="post" name="form1"  >
    


    <div class="form-group">
      <label >Name:</label>
      <div class="input-group">
      <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
      <input class="form-control" placeholder="Enter Name" type="text" name="name" required/>
      </div>
    </div>




    <div class="form-group">
      <label for="gender">Male:</label>
      <input  class="form-control" type="radio" name="gender" value="M" required />
      <label for="f">Female:</label>
      <input  class="form-control" type="radio" name="gender" value="F" required/>
    </div>





    <div class="form-group">
     <label for="date">Date Of Birth:</label>
     <input  class="form-control" type="date" name="dob" required >
    </div>





    <div class="form-group">
      <label for="pwd">Addtess:</label>
      <textarea  class="form-control" name="address" required placeholder="Enter Address"></textarea>
    </div>





    <div class="form-group">
    <label for="pwd">City:</label>
     <select   class="form-control" name="city" required>
          <option value="" selected="selected" disabled="disabled">Select your Country</option>
          <option>Toronto</option>
          <option>Ottawa</option>
          <option>Edmonton</option>
          <option>Mississauga</option>
          <option>Winnipeg</option>
          <option>Vancouver</option>
          <option>Brampton</option>
          <option>Hamilton</option>
          <option>Quebec City</option>
          <option>Surrey</option>
          <option>Halifax</option>
          <option>London</option>
          <option>Vaughan</option>
          <option>Kitchener</option>
          <option>Burnaby</option>
          <option>Windsor</option>
          <option>Regina</option>
          <option>Richmond Hill</option>
        </select>
    </div>




    <div class="form-group">
    <label for="pwd">Province:</label>
     <select   class="form-control"  name="province" required>
          <option value="" selected="selected" disabled="disabled">Select your Country</option>
          <option>Alberta</option>
          <option>British Columbia</option>
          <option>Manitoba</option>
          <option>Manitoba</option>
          <option>New Brunswick</option>
          <option>Newfoundland and Labrador</option>
          <option>Nova Scotia</option>
          <option>Ontario</option>
          <option>Prince Edward Island</option>
          <option>Quebec</option>
          <option>Saskatchewan</option>
          <option>Northwest Territories</option>
          <option>Nunavut </option>
          <option>Yukon</option>

        </select>
    </div>



   <div class="form-group">
      <label for="post">Postal Code:</label>
     <input class="form-control" type="text" pattern="[0-9]*" maxlength="6" name="post" required placeholder="Enter Postal Code"/>
    </div>



    <div class="form-group">
      <label for="email">Email:</label>
      <input class="form-control" type="text" name="email" required placeholder="Enter Email ID">
    </div>






    <div class="form-group">
      <label for="email">Website link:</label>
       <input class="form-control" type="url" name="link" required placeholder="Enter Website Link">
    </div>


     <div class="form-group">
     <label for="date">Joining Date:</label>
     <input  class="form-control" type="date" name="djoin" required>
    </div>


     <div class="form-group">
      <label for="post">Annual Basic Pay:</label>
     <input class="form-control" type="text" pattern="[0-9]*" maxlength="20" name="pay" required placeholder="Enter Annual Basic Pay"/>
    </div>


  



   <input class="btn btn-block btn-primary" class="form-control" type="submit" name="Submit" value="Add"><br>
    <div class="form-group">
              <hr />
            </div>
   <input class="btn btn-block btn-primary" class="form-control" type="reset">
   <hr />
  </form>
</div>

</div>


<div class="page-header">
    	
    	</div>

    </div>
    
    </div>






    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>
