<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
<style type="text/css">body{
    font-family:Lato;
}
.img {
    max-width: 100%;
    max-height: 600px;
    min-height: 600px;
}
.search-text{
  margin-top:50px;
  background-color:#2d2d2d;
  padding-top:60px;
  padding-bottom:60px;
}
  
.search-text .input-search{
  height:45px;
  width:40%;
  padding-left:20px;
    color:#333;
} 

.search-text .btn-search{
    background:#3d6c8a;
    border:none;
  color:#FFF;
  height: 45px;
    width: 80px;
}

.search-text h4{
    color: #FFF;
    font-weight: 700;
}

footer{
     background-color:#252525;
     padding:30px 0px;
}        

.logo{
    color:#FFF;
    font-weight:800;
    font-size:30px;
}

.adress span , .menu span{
   color: #FFF; 
   font-weight: 800; 
   border-bottom: 1px solid #c7c7c7; 
   padding-bottom: 10px; 
   margin-bottom: 20px;
   display: block;
   text-transform: uppercase;
   font-size: 16px;
   letter-spacing: 3px;
}
 
.adress , .menu{
    list-style: none;
}

.adress li , .menu li{
    margin-top:10px;
}

.adress li a , .menu li a{
    color:#FFF;
    text-decoration:none;
    font-size:14px;
}

#icons{
    padding:50px 0px;
}

#icons .fa{
    font-size:18px;
    color: #3d6c8a;
    width: 35px;
    height: 35px;
    line-height: 35px;
}

#icons .fa:hover{
    color:#FFF;
    background-color:#3d6c8a;
    -webkit-transition: all 2s ease-in-out;
    -moz-transition: all 2s ease-in-out;
    -o-transition: all 2s ease-in-out;
    transition: all 2s ease-in-out;
}

.btn-large{
   background:#3d6c8a;
    border:none;
  color:#FFF;
  height: 45px;
    width:40%;
}
</style>
</head>
<body style="background-image: url(i.jpg);" position: fixed;>

		<?php include 'nav.php'; ?>


	<div id="wrapper">

	<div class="container">
    
    	<div class="page-header">
    	<h3>Payroll Management System.</h3>
    	</div>
        
        <div class="row">
        <div class="col-lg-12">
        <h1>welcome</h1>
        </div>
        </div>

    
    </div>
    
    </div>



    <div class="container" >
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner"  >

      <div class="item active">

        <img src="o1.jpg" alt="Los Angeles" style="width:100%;" style="max-height: 50%" class="img">
        <div class="carousel-caption">

          <h3>RSG Office</h3>
          <p>LA is always so much fun!</p>
        </div>
      </div>

      <div class="item">
        <img src="c.jpg" alt="Chicago" style="width:100%;" style="max-height: 50%" class="img">
        <div class="carousel-caption">
          <h3>RSG Professionals</h3>
          <p>Thank you, Chicago!</p>
        </div>
      </div>
    
      <div class="item">
        <img src="a.jpg" alt="New York" style="width:100%;" style="max-height: 50%" class="img">
        <div class="carousel-caption">

          <h3>RSG Work </h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
      <div class="search-text"> 
       <div class="container">
         <div class="row text-center">
         
           <div class="form">
               <h4>SIGN OUT </h4>
                <button class="input-search" style="width: 40%"><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></button>
            </div>
        
          </div>         
       </div>     
  </div>
  
    <footer>
       <div class="container">
           <div class="row text-center">
                
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                  <ul class="menu">
                        <span>RSG Group</span>    
                       <img src="r.svg" alt="Chicago" style="width:100%;">
                      </ul>
                </div>
                
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <ul class="menu">
                         <span>Menu</span>    
                         <li>
                            <a href="home.php">Home</a>
                          </li>
                               
                          <li>
                             <a href="add.php">Add</a>
                          </li>
                               
                          <li>
                            <a href="table.php">List</a>
                          </li>
                               
                          <li>
                             <a href="print.php">Print </a>
                          </li>
                     </ul>
                </div>
           
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                  <ul class="adress">
                        <span>RSG Partner</span>       
                        <img src="l.png" alt="Chicago" style="width:100%;">
                   </ul>
               </div>
               
               
               <div class="col-lg-8 col-lg-offset-2" id="icons">
                  <div class="col-lg-2">
                         <a href='http://www.fb.com'><i class="fa fa-facebook"></i></a>
                  </div>
                  <div class="col-lg-2">
                        <a href="http://www.github.com"><i class="fa fa-github"></i></a>
                  </div>
                  <div class="col-lg-2">
                        <a href="http://www.google.com"><i class="fa fa-google"></i></a>
                  </div>
                  <div class="col-lg-2">
                         <a href="http://www.tumbler.com"><i class="fa fa-twitter"></i></a>
                  </div>
                  <div class="col-lg-2">
                         <a href="http://www.linkedin.com"><i class="fa fa-linkedin"></i></a>
                  </div>
                  <div class="col-lg-2">
                        <a href="http://www.dropbox.com"><i class="fa fa-dropbox"></i></a>
                  </div>
                  
               </div>
                 
          
           </div> 
        </div>
    </footer>
    
</body>
</html>
<?php ob_end_flush(); ?>